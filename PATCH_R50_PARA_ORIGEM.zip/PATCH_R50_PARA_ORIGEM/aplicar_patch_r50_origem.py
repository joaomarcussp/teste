"""Aplica o PATCH_R50 (somente CÓDIGO) no projeto ORIGEM (dados reais).

Uso no Spyder: preencha o bloco CONFIGURAÇÃO e execute (F5).
Não toca em XLSX, TXT, JSON de estado nem em nenhum dado. Não executa o fluxo
e nunca aprova baseline. Conferência por SHA-256, backup, rollback e idempotência.
Nada é impresso além de caminhos relativos de código e hashes.
"""
from __future__ import annotations
import datetime as dt, hashlib, json, shutil, subprocess, sys
from pathlib import Path

# ===================== CONFIGURAÇÃO =====================
PROJETO = r""            # pasta Reconciliacao_Atas_v2 da ORIGEM (já em R49)
MODO = "CONFERIR"        # "CONFERIR" (não altera nada)  ->  depois "APLICAR"
RODAR_TESTES = True      # após APLICAR, roda tests.test_r50_hardening + tests.test_r49_residuais
# ========================================================

AQUI = Path(__file__).resolve().parent

# Arquivos da R49 que a R50 NÃO pode alterar (só informativo: confirma que a origem está na R49)
PRESERVADOS_R49 = {
    "scripts/aprovacao_origem.py": "e7de52ad6782259275629bbed24bf885c45412c6140171a94adc59bf02914438",
    "scripts/gate21_recon_enriquecida.py": "ff960091317d2ebb684d90366b81716472cbd707bc0c05a0c241fe58f5c304f7",
    "scripts/gate27_visao_consolidada.py": "521e7491b44c21ea1fcd9a8221ecf989023aa3ab0917831d612ce3d4de274593",
    "revisao_ultimate/double_check_independente.py": "cc13da227fbac43e83b7e032ec34867e057b97ef160b5c0f26c5317e9a753a44",
}


def sha(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def classificar(alvo: Path, man: dict):
    """Retorna (lista de (item, estado)). Estados: JA_R50, APLICAVEL, DIVERGENTE."""
    res = []
    for it in man["arquivos"]:
        p = alvo / it["arquivo"]
        cur = sha(p) if p.exists() else None
        if cur == it["sha256_r50"]:
            est = "JA_R50"
        elif cur == it["sha256_r49"]:  # None == None cobre arquivo novo ausente
            est = "APLICAVEL"
        else:
            est = "DIVERGENTE"
        res.append((it, est, cur))
    return res


def main(alvo: Path, modo: str) -> int:
    man = json.loads((AQUI / "manifesto_patch_r50.json").read_text("utf-8"))
    if not (alvo / "scripts").is_dir() or not (alvo / "revisao_ultimate").is_dir() or not (alvo / "tests").is_dir():
        print("PATCH_ABORTADO: a pasta não parece ser Reconciliacao_Atas_v2"); return 2

    # integridade do próprio patch
    for it in man["arquivos"]:
        src = AQUI / "arquivos" / it["arquivo"]
        if not src.exists() or sha(src) != it["sha256_r50"]:
            print("PATCH_ABORTADO: o pacote do patch está corrompido em", it["arquivo"]); return 2

    print("== Conferência dos arquivos preservados (devem estar iguais à R49) ==")
    fora = 0
    for rel, h in PRESERVADOS_R49.items():
        p = alvo / rel
        ok = p.exists() and sha(p) == h
        fora += (not ok)
        print(f"  {'OK ' if ok else 'DIF'}  {rel}")
    if fora:
        print("  AVISO: a origem não parece estar exatamente na R49. Não force; envie esta lista.")

    print("== Arquivos do patch ==")
    cl = classificar(alvo, man)
    bloqueios, avisos, pend, ja = [], [], [], 0
    for it, est, cur in cl:
        print(f"  {est:10s} {it['arquivo']}  ({it['tipo']})")
        if est == "JA_R50":
            ja += 1
        elif est == "APLICAVEL":
            pend.append(it)
        elif it["tipo"] == "teste":
            avisos.append((it, cur))      # teste local diferente: não bloqueia, não sobrescreve
        else:
            bloqueios.append((it, cur))   # código/config diferente: bloqueia

    for it, cur in avisos:
        print(f"  AVISO teste divergente (mantido, não sobrescrito): {it['arquivo']} sha={cur}")
    if bloqueios:
        print("PATCH_ABORTADO (nada foi alterado). Versão inesperada em:")
        for it, cur in bloqueios:
            print(f"  - {it['arquivo']}  local={cur}  esperado_R49={it['sha256_r49']}")
        print("Não force. Envie esta saída para revisão.")
        return 3

    if modo != "APLICAR":
        print(f"CONFERENCIA_OK: {len(pend)} a aplicar, {ja} já em R50, {len(avisos)} aviso(s). "
              f'Para aplicar, troque MODO = "APLICAR".')
        return 0
    if not pend:
        print(f"PATCH_JA_APLICADO: {ja} arquivo(s) já em R50; nada a fazer"); return 0

    bk = alvo / "_backup_patch_r50" / dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    for it in pend:
        p = alvo / it["arquivo"]
        if p.exists():
            d = bk / it["arquivo"]; d.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(p, d)
    try:
        for it in pend:
            d = alvo / it["arquivo"]; d.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(AQUI / "arquivos" / it["arquivo"], d)
        erros = [it["arquivo"] for it in pend if sha(alvo / it["arquivo"]) != it["sha256_r50"]]
        if erros:
            raise RuntimeError("pós-verificação falhou: " + repr(erros))
    except Exception as e:
        for it in pend:
            old = bk / it["arquivo"]; d = alvo / it["arquivo"]
            if old.exists(): shutil.copy2(old, d)
            elif d.exists(): d.unlink()
        print("PATCH_REVERTIDO:", e); return 4
    print(f"PATCH_R50_OK: {len(pend)} arquivo(s) aplicados, {ja} já em R50; backup em {bk}")

    if RODAR_TESTES:
        print("== Testes dirigidos (esperado: 26 testes, OK) ==")
        r = subprocess.run([sys.executable, "-m", "unittest", "tests.test_r50_hardening", "tests.test_r49_residuais"],
                           cwd=alvo)
        print("TESTES_RC =", r.returncode)
        return 0 if r.returncode == 0 else 5
    return 0


if __name__ == "__main__":
    alvo = sys.argv[1] if len(sys.argv) > 1 else PROJETO
    if not alvo:
        print("Preencha PROJETO no bloco CONFIGURAÇÃO e execute novamente."); raise SystemExit(2)
    modo = (sys.argv[2] if len(sys.argv) > 2 else MODO).upper()
    raise SystemExit(main(Path(alvo).resolve(), modo))
