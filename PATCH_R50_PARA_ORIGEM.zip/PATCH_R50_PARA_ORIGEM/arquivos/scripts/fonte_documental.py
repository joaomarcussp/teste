"""R34 - conferencia do achado CONTRA O DOCUMENTO-FONTE (TXT).

Auditoria independente das 106 confirmadas R33 (4 lotes, leitura do TXT):
43 falsos positivos. As classes que se repetem e que o motor nao olhava:

  * o documento-fonte DECLARA o valor do sistema - "Proposta: majoracao ...
    para R$40 MM" com "Decisao: Aprovado conforme proposto ... Limite R$ 2 MM"
    (TAROFIPE FACEVEKE); ERRATA no mesmo processo corrigindo 75 -> 87,5
    (MUTASEJI); quadro "Proposta" com o total do sistema (ZUDIVOTI);
  * o documento-fonte decide o rating do SISTEMA e a extracao gravou outra
    nota (TABEFOTI: "Rating A+" x extraido BBB-; FIDC KONAZUJA: A- x A).

Este modulo so' LE o documento: devolve valores monetarios e notas de rating
com a ancora e o contexto em que aparecem. Quem decide o efeito e' a
autochecagem (gate99), que so' rebaixa (confirmada -> manual) ou, para
rating, declara falso positivo quando o documento decide a nota do sistema e
nao cita a nota usada.

Contextos que NAO valem como valor/nota deliberada:
  - "atual", "vigente", "anterior", "existente", "hoje" logo antes;
  - "de R$ X para ..." (X e' o valor antigo);
  - indicadores financeiros da empresa (receita, divida, EBITDA, caixa...).
"""
from __future__ import annotations

from functools import lru_cache
import re
import unicodedata
from typing import List, Optional, Set, Tuple

_NUM = r"(\d{1,3}(?:\.\d{3})+(?:,\d+)?|\d+(?:,\d+)?|\d+\.\d+)"
_RE_MON = re.compile(
    r"(R\$|US\$|USD|U\$)?\s*~?\s*(?<![\d.,])" + _NUM +
    r"\s*(MM|mm|Mm|MI|Mi|mi|milh(?:ão|ao|ões|oes)|bi|BI|Bi|bilh(?:ão|ao|ões|oes)|mil|k)?(?![\w])")
# R37 (auditoria da R35, contraprova RF-W): "O limite ERA de R$ 100 MM.
# Decisao: aumentar para R$ 150 MM" - o valor historico nao corrobora o
# sistema. Tempo verbal passado / estado anterior logo antes do valor.
_ANTIGO_ANTES = re.compile(r"(atual|vigente|anterior|existente|hoje|previo|antigo"
                           r"|\b(?:era|eram|estava|estavam|havia|tinha|tinham|possu[ií]a|vigorava|anteriormente)\b)"
                           r"\W{0,3}(\w+\W{1,3}){0,3}$",
                           re.IGNORECASE)
_PARA_DEPOIS = re.compile(r"^\s*(MM|mi|milh\w*|bi|bilh\w*)?\s*(\([^)]{0,30}\))?\s*(para|->|→)\b", re.IGNORECASE)
# R36 (caso CB Participacoes): "foi aprovado LIMITE DE R$ 5,4 milhoes para
# emissao de carta fianca" nao e' "de X para Y": quando o valor vem logo
# depois de "limite (de)" e o "para" NAO e' seguido de outro valor, a
# citacao vale (o "para" diz a finalidade). "de R$ 100 MM para R$ 150 MM"
# continua excluido.
_PARA_VALOR = re.compile(r"^\s*(MM|mi|milh\w*|bi|bilh\w*)?\s*(\([^)]{0,30}\))?\s*(para|->|→)\s*(?:R\$|US\$|\d)",
                         re.IGNORECASE)
_LIMITE_ANTES = re.compile(r"\blimite\s+(?:\w+\s+){0,2}?(?:de\s+|no\s+valor\s+de\s+)?(?:R\$|BRL)?\s*$", re.IGNORECASE)
_FINANCEIRO = re.compile(
    r"\b(receitas?|faturamento|ebitda|ebit|d[ií]vidas?|lucro|patrim[oô]nio|caixa|capex|ncg|"
    r"pl|ativos?|passivos?|margem|resultados?|capital social|aporte|vendas?|investimentos?|"
    r"custos?|despesas?|valor de mercado|market cap|capta[cç][aã]o|emiss[aã]o)\b",
    re.IGNORECASE)


def _sem_acento(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))


def _para_float(n: str) -> Optional[float]:
    n = n.strip()
    try:
        if re.fullmatch(r"\d{1,3}(?:\.\d{3})+(?:,\d+)?", n):
            return float(n.replace(".", "").replace(",", "."))
        if "," in n:
            return float(n.replace(",", "."))
        return float(n)
    except ValueError:
        return None


def valores_monetarios(texto: Optional[str]) -> List[Tuple[float, str]]:
    """[(valor_em_reais, contexto)] para quantias com R$ OU com unidade
    (MM/milhoes/bi). Exclui moeda estrangeira, valor antigo e indicador
    financeiro da empresa."""
    if not texto:
        return []
    out = []
    for m in _RE_MON.finditer(texto):
        moeda, num, uni = m.group(1), m.group(2), m.group(3)
        if moeda and moeda.upper() in ("US$", "USD", "U$"):
            continue
        if not moeda and not uni:
            continue
        v = _para_float(num)
        if v is None or v == 0:
            continue
        u = (uni or "").lower()
        if u in ("mm", "mi") or u.startswith("milh"):
            v *= 1e6
        elif u == "bi" or u.startswith("bilh"):
            v *= 1e9
        elif u in ("mil", "k"):
            v *= 1e3
        elif v < 1000:            # "R$ 40" sem unidade: escala desconhecida
            continue
        antes = texto[max(0, m.start() - 60): m.start()]
        depois = texto[m.end(): m.end() + 25]
        if _ANTIGO_ANTES.search(antes[-35:]):
            continue
        if _PARA_DEPOIS.match(depois) and (_PARA_VALOR.match(depois)
                                           or not _LIMITE_ANTES.search(texto[max(0, m.start() - 40): m.start()])):
            continue
        if _FINANCEIRO.search(antes[-45:]):
            continue
        # resolucao da citacao: unidade do ultimo digito escrito x escala
        # ("R$ 0,2 MM" -> 100 mil). Usada para nao tomar arredondamento
        # por declaracao do valor (SAUDE BH: 0,2 MM x 0,22 MM).
        dec = num.split(",")[1] if "," in num else (num.split(".")[1] if re.fullmatch(r"\d+\.\d+", num) else "")
        esc = v / _para_float(num) if _para_float(num) else 1.0
        resol = esc * (10 ** -len(dec)) if dec else esc
        out.append((v, (antes[-70:] + texto[m.start():m.end()]).replace("\n", " "), resol, antes[-45:]))
    return out


_CTX_LIMITE = re.compile(r"limit|global|total|soma|aprova|propost|errata|corrig|decis", re.IGNORECASE)


def cita_valor(texto: Optional[str], valor: Optional[float], outro: Optional[float] = None,
               tol_abs: float = 1000.0, tol_rel: float = 0.001) -> Optional[str]:
    """Contexto da primeira citacao do valor COMO LIMITE (ancora de limite/
    total/aprovacao/proposta/errata logo antes), com precisao suficiente
    para distinguir `valor` de `outro` (o valor da ata)."""
    if valor is None or not texto:
        return None
    for v, ctx, resol, pre in valores_monetarios(texto):
        # R36 (caso CB Participacoes: documento "R$ 5,4 milhoes" x sistema
        # 5.432.785,19): a citacao vale ate' a precisao ESCRITA (meia unidade
        # do ultimo digito), so' quando essa precisao e' fina (<= 2% do valor)
        _tol_cit = resol / 2 if resol <= 0.02 * abs(v) else 0.0
        if abs(v - valor) > max(tol_abs, tol_rel * abs(valor), _tol_cit):
            continue
        if outro is not None and resol / 2 >= abs(valor - outro):
            continue                      # arredondamento: nao distingue
        if not _CTX_LIMITE.search(pre):
            continue
        return ctx
    return None


_NOTA = r"(AAA|AA[+-]?|A[+-]?|BBB[+-]?|BB[+-]?|B[+-]?|CCC[+-]?|CC|C|D)"
_RE_RATING = re.compile(
    r"\bRating\s*(?:final|proposto|atribu[ií]do|mantido|aprovado|do grupo|:)?\s*:?\s*(?:de\s+)?"
    + _NOTA + r"(?![A-Za-z+-])", re.IGNORECASE)


def notas_decididas(texto: Optional[str]) -> Set[str]:
    """Notas ancoradas em 'Rating ...' que NAO sao 'Rating Atual/Vigente/
    Anterior'. Ex.: 'Rating Atual: A- | Rating Proposto: A-' -> {'A-'}."""
    if not texto:
        return set()
    out = set()
    for m in _RE_RATING.finditer(texto):
        nota = m.group(1).upper()
        if m.group(1) != nota:           # "Rating de a..." minusculo nao e' nota
            continue
        antes = texto[max(0, m.start() - 25): m.start()]
        if re.search(r"(atual|vigente|anterior|antigo|hoje)\W*$", antes, re.IGNORECASE):
            continue
        # "Rating AA- para A+" / "rating de BBB- para BB": a primeira e' a
        # nota ANTIGA; a decidida e' a que vem depois de "para"
        seg = re.match(r"\s*(?:para|->|→)\s*" + _NOTA + r"(?![A-Za-z+-])", texto[m.end(): m.end() + 14])
        if seg:
            out.add(seg.group(1).upper())
            continue
        out.add(nota)
    return out


# ------------------------------------------------ quadro: linha "Total GERAL"
# A anonimizacao das entradas trocou "Total" por pseudonimo ("Jotecoga
# GERAL"); aceita-se qualquer primeira palavra seguida de GERAL, desde que a
# linha traga celulas numericas num bloco de quadro com escala DECLARADA.
_RE_GERAL = re.compile(r"^\s*\S+\s+GERAL\b", re.IGNORECASE)
# R39 (JOPUSELU: "nao somou todos os valores do termsheet"): o total geral do
# quadro aparece tambem como "<Total> Banco XP" ou "<Total> Grupo Economico"
# (252 blocos sem linha GERAL). Vale so' quando o bloco nao tem linha GERAL.
_RE_GERAL_ALT = re.compile(r"^\s*\S+\s+(?:Banco\s+XP|Grupo\s+Econ[oô]mico)\b", re.IGNORECASE)


def linhas_total_geral(bloco_texto: str):
    """[(linha, fim_do_rotulo)] das linhas de TOTAL GERAL do bloco: 'GERAL'
    ou, sem ela, 'Banco XP'/'Grupo Economico'."""
    linhas = bloco_texto.split("\n")
    g = [(ln, _RE_GERAL.match(ln).end()) for ln in linhas if _RE_GERAL.match(ln)]
    if g:
        return g
    return [(ln, _RE_GERAL_ALT.match(ln).end()) for ln in linhas if _RE_GERAL_ALT.match(ln)]


def celulas_total_geral(texto: Optional[str]) -> List[Tuple[List[float], float, str]]:
    """[(valores_em_reais_na_ordem_das_colunas, resolucao, linha)] das linhas
    'Total GERAL' de quadros com escala declarada."""
    if not texto:
        return []
    import quadro_reader as qr
    out = []
    for bloco in qr.extrair_blocos_quadro(texto):
        esc = bloco.escala
        if esc is None:
            continue
        for ln, _fim in linhas_total_geral(bloco.texto):
            cel = [v * float(esc) for v in qr.ler_celulas_numericas(ln[_fim:])]
            # R36: celulas CRUAS da linha (a leitura numerica descarta zeros
            # "0,0"/"o,o" do OCR e inteiros "1000" - caso Sagibosi: so' o
            # primeiro valor era lido e a "ultima celula" virava a ATUAL)
            _cru = celulas_cruas(ln)
            if _cru and len(_cru) >= len(cel):
                cel = [v * float(esc) for v in _cru]
            if cel:
                dec = re.findall(r"\d+,(\d+)", ln)
                casas = max((len(x) for x in dec), default=0)
                out.append((cel, float(esc) * 10 ** -casas, ln.strip()[:120]))
                _CAB_TOTAL[ln.strip()[:120]] = bloco.texto[:600]
    return out


_CAB_TOTAL = {}      # linha TOTAL GERAL -> inicio do bloco (cabecalho), R36
_RE_CEL_NUM = re.compile(r"\d{1,3}(?:\.\d{3})+(?:,\d+)?|\d+(?:,\d+)?|[oO0],[oO0]|-")


def celulas_cruas(ln) -> List[float]:
    """Celulas numericas da linha TOTAL, na ordem (tabulacao separa colunas;
    sem tabulacao, espacos apos 'GERAL'). Texto de nota ('PFE zerando em 30
    meses', 'Cashcol de 40%') fica na celula de rotulo e nao conta."""
    resto = re.split(r"GERAL", ln, maxsplit=1, flags=re.IGNORECASE)[-1]
    partes = resto.split("\t") if "\t" in resto else resto.split()
    out = []
    for p in partes:
        p = p.strip().rstrip(":;.")
        if not p:
            continue
        if not _RE_CEL_NUM.fullmatch(p):
            continue
        out.append(0.0 if p in ("-",) else (_para_float(p.replace("o", "0").replace("O", "0")) or 0.0))
    return out


def _cabecalho_atual_risco_proposta_disp(linha) -> bool:
    """O bloco declara as colunas ATUAL ... Risco ... Proposta ... Disp.?"""
    cab = _sem_acento(_CAB_TOTAL.get(linha, "")).lower()
    i_at, i_ri = cab.find("atual"), cab.find("risco")
    i_pr, i_di = cab.find("proposta"), cab.find("disp")
    return min(i_at, i_ri, i_pr, i_di) >= 0 and i_at < i_pr and i_ri < i_di


def total_geral_proposto(texto, valor_sistema, valor_ata, tol_abs=1000.0, tol_rel=0.001):
    """Linha 'Total GERAL' do quadro em que o valor do SISTEMA aparece como
    coluna PROPOSTA: e' a ultima celula, ou aparece DEPOIS do valor da ata
    (quadros 'Aprovacao ATUAL | Proposta'). Sistema so' na coluna ATUAL
    (antes do valor da ata) = sistema desatualizado -> nao conta."""
    for cel, resol, ln in celulas_total_geral(texto):
        if resol / 2 >= abs(valor_sistema - valor_ata):
            continue
        ok = lambda v, a: abs(v - a) <= max(tol_abs, tol_rel * abs(a))
        # R36 (caso SOGADOCU: 'GERAL 16 6 26 20'): quadro ATUAL | Risco |
        # Proposta | Disp. - quatro celulas com Disp. = Proposta - Risco. Com
        # o leiaute CONFIRMADO pela identidade, a coluna Proposta e' a
        # terceira, e so' ela decide (o valor da ata pode coincidir com Disp.)
        if len(cel) < 2:
            continue                      # uma celula so': nao ha' coluna para decidir
        if len(cel) == 4 and (abs(cel[2] - cel[1] - cel[3]) <= max(resol, 0.005 * abs(cel[2]), tol_abs)
                              or _cabecalho_atual_risco_proposta_disp(ln)):
            # leiaute confirmado pela identidade OU pelo cabecalho do bloco
            # (caso FUSEDAJI: 'GERAL 267,4 0,0 53,6 49,3' - risco da linha
            # nova fora da coluna; cabecalho ATUAL | Risco | Proposta | Disp.)
            if ok(cel[2], valor_sistema) and not ok(cel[2], valor_ata):
                return ln
            continue
        pos_s = [i for i, v in enumerate(cel) if ok(v, valor_sistema)]
        if not pos_s:
            continue
        pos_a = [i for i, v in enumerate(cel) if ok(v, valor_ata)]
        if (pos_a and max(pos_s) > max(pos_a)) or (not pos_a and pos_s[-1] == len(cel) - 1):
            return ln
    return None


def soma_itens_da_proposta(texto, valor_sistema, valor_ata, tol_abs=1000.0, tol_rel=0.001):
    """A linha 'Proposta:'/'Decisao:' aprova VARIOS itens cuja soma e' o
    valor do sistema e um deles e' o valor usada da ata (Bumijono: fianca
    ajustada R$ 4,2 MM + nova fianca R$ 1,0 MM = R$ 5,2 MM no sistema)."""
    if not texto:
        return None
    ok = lambda v, a: abs(v - a) <= max(tol_abs, tol_rel * abs(a))
    for ln in texto.split("\n"):
        if not re.match(r"\s*(Proposta|Decis[aã]o)\b", ln, re.IGNORECASE):
            continue
        vals = []
        for v, _c, _r, _p in valores_monetarios(ln):
            if not any(ok(v, x) for x in vals):
                vals.append(v)
        if len(vals) >= 2 and any(ok(v, valor_ata) for v in vals) and ok(sum(vals), valor_sistema):
            return ln.strip()[:160]
    return None


def secao_por_cabecalho_simples(texto: Optional[str], nome: str,
                                titulo_de_pauta: bool = False) -> Optional[Tuple[str, int, int]]:
    """Secao de ata consolidada cujo TITULO e' so' o nome da entidade (sem
    travessao de pauta), seguido de 'Proposta:' em ate' 4 linhas (caso
    Rorakego Pujavadi). Termina 2 linhas antes da 'Proposta:' seguinte.
    Exige titulo UNICO; na duvida, None."""
    if not texto or not nome:
        return None
    alvo = re.sub(r"[^A-Z0-9]+", " ", _sem_acento(nome).upper()).strip()
    if len(alvo) < 4:
        return None
    L = texto.split("\n")
    props = [i for i, l in enumerate(L) if re.match(r"\s*Proposta\s*:", l)]
    exatos, prefixo, pauta = [], [], []
    for i, l in enumerate(L):
        n = re.sub(r"[^A-Z0-9]+", " ", _sem_acento(l).upper()).strip()
        if not any(i < p <= i + 4 for p in props):
            continue
        if n == alvo:
            exatos.append(i)
        elif n.startswith(alvo + " ") and len(n) <= len(alvo) + 40:
            prefixo.append(i)
        elif (titulo_de_pauta and n.startswith(alvo + " ")
              and re.match(r"\s*" + r"\W*".join(re.escape(t) for t in alvo.split()) + r"\s+[-–—]\s+",
                           _sem_acento(l).upper())):
            # R36 (caso BANCO KISEMUJU, ata 19.06.2026): titulo de pauta longo
            # "Banco Kisemuju - Tupenira do Limite de DI ..., dos atuais R$ 500mm
            # para R$ 700mm ..." seguido de "Proposta:"
            pauta.append(i)
    cands = exatos or prefixo or pauta     # titulo exato tem precedencia
    if len(cands) != 1:
        return None
    i0 = cands[0]
    p0 = next(p for p in props if p > i0)
    p1 = next((p for p in props if p > p0), None)
    i1 = (p1 - 2) if p1 else len(L)
    return "\n".join(L[i0:i1]), i0 + 1, i1


# ---------------------------------------------------------------------------
# R36 - documento-fonte compartilhado (gate21 e gate99) e escopo do quadro
# ---------------------------------------------------------------------------
#
# Caso do operador (R36): "pq diz que tem produto fora do escopo?" e "fianca
# esta' no escopo", "CPR e NC estao no escopo". O gate21 marcava o limite
# global como "Nao comparavel - inclui itens fora do escopo" SEMPRE que a
# deliberacao nao abria o limite por produto, sem olhar o documento. A
# regra passa a exigir EVIDENCIA: produto da lista de exclusao (regras_base
# escopo.excluir) com valor numa linha do QUADRO do limite no documento-fonte.
# Cabecalho de limite separado ("Custodia: R$ 500 MM | 10 anos") nao conta:
# e' outro limite, fora do global.

def pastas_do_indice(indice) -> dict:
    """pasta do processo -> [grupos de arquivo do TXT] (atas consolidadas
    ficam de fora: nelas so' vale a secao do grupo)."""
    from collections import defaultdict
    out = defaultdict(list)
    for gtx in getattr(indice, "grupos", []) or []:
        cam = str(gtx.arquivo_resolvido or "").replace("/", "\\")
        if "ATA ATACADO" in cam.upper():
            continue
        out[cam.rsplit("\\", 1)[0]].append(gtx)
    return out


def fontes_documentais(indice, txt_ids, nomes, por_pasta, vistos=None, quadros_do_grupo=False) -> list:
    """[(rotulo, texto)] dos documentos-fonte: ata consolidada -> SO' a secao
    do grupo (sem secao segura, nada); Fast-Track/e-mail -> o documento e os
    demais do mesmo processo (pasta: respostas, ERRATA)."""
    import revisao_documental as rv
    out = []
    vistos = set() if vistos is None else vistos
    for t in txt_ids:
        gtx = indice.grupo_de_txt_id(t) if indice is not None else None
        if gtx is None:
            continue
        cam = str(gtx.arquivo_resolvido or "").replace("/", "\\")
        if "ATA ATACADO" in cam.upper():
            for n in nomes:
                sec = (rv.secao_do_grupo(gtx.texto, n)
                       or secao_por_cabecalho_simples(gtx.texto, n, titulo_de_pauta=quadros_do_grupo))
                if sec and ("ata", cam, sec[1]) not in vistos:
                    vistos.add(("ata", cam, sec[1]))
                    out.append((f"seção '{n}' da {cam.rsplit(chr(92), 1)[-1][:60]}", sec[0]))
                    break
            # R36 (caso BANCO KISEMUJU): na ata consolidada os quadros vem como
            # imagens no FIM do documento, fora da secao; o quadro do grupo e'
            # o bloco cujo CABECALHO nomeia o grupo ("BANCO_KISEMUJU | BRL MM
            # Aprovacao ATUAL ... Proposta"). So' para a evidencia de ESCOPO
            # (gate21): as regras RF do gate99 continuam so' com a secao (o
            # quadro pode ser de outra data/deliberacao do mesmo grupo)
            for n in (nomes if quadros_do_grupo else []):
                alvo = re.sub(r"[^A-Z0-9]+", " ", _sem_acento(str(n)).upper()).strip()
                if len(alvo) < 5 or not any(len(t) >= 5 for t in alvo.split()):
                    continue
                for bl in blocos_de_quadro(gtx.texto):
                    cab = " " + re.sub(r"[^A-Z0-9]+", " ", _sem_acento("\n".join(bl.split("\n")[1:3])).upper()) + " "
                    if f" {alvo} " in cab and ("quadro", cam, bl[:200]) not in vistos:
                        vistos.add(("quadro", cam, bl[:200]))
                        out.append((f"quadro '{n}' da {cam.rsplit(chr(92), 1)[-1][:60]}", bl))
            continue
        for g2 in por_pasta.get(cam.rsplit("\\", 1)[0], []) or [gtx]:
            c2 = str(g2.arquivo_resolvido)
            if c2 in vistos:
                continue
            vistos.add(c2)
            out.append((c2.replace("/", "\\").rsplit("\\", 1)[-1][:80], g2.texto or ""))
    return out


_FORA_ESCOPO_QUADRO = re.compile(
    r"cust[oó]dia|revolv\w*|\bfgc(?:oop)?\b|compromissad\w*|\brepo\b|lf\s*s[eê]nior|\blfsn\b"
    r"|letras?\s+financeiras?|vendor", re.IGNORECASE)
_CAB_QUADRO_LIMITE = re.compile(r"BRL\s*MM|Aprova[cç][aã]o|Proposta|\bLinha\b", re.IGNORECASE)


@lru_cache(maxsize=512)
def _blocos_de_quadro_cached(texto: str) -> tuple:
    """R41-PERF: mesma leitura de blocos, memoizada por texto imutavel.

    gate21/gate99 consultam repetidamente o mesmo TXT para grupos/campos
    distintos. O regex split sobre documentos grandes era refeito centenas
    de vezes. A memoizacao NAO muda classificacao nem conteudo; so evita
    rescans do mesmo texto.
    """
    out = []
    for bl in re.split(r"(?=##BLOCO \d+\|)|(?=\[ANEXO )", texto):
        if not bl.startswith("##BLOCO") or "TABELA" not in bl.split("\n", 1)[0]:
            continue
        if _CAB_QUADRO_LIMITE.search(bl[:400]):
            out.append(bl)
    return tuple(out)


def blocos_de_quadro(texto: Optional[str]) -> List[str]:
    """Blocos de tabela (OCR '##BLOCO n|TABELA') com cara de quadro de limite
    (cabecalho com 'BRL MM', 'Aprovacao', 'Proposta' ou 'Linha')."""
    return list(_blocos_de_quadro_cached(texto or ""))


# ---------------------------------------------------------------- R38
# Total do quadro na coluna PROPOSTA, sem depender do valor do sistema
# (analista: JF ZALOFIGU/KEREZOPU "nao somou garantia firme"; ZUDIVOTI
# "onde tirou 355,4?" - o resumo trazia o total ATUAL, o quadro a Proposta).
_RE_TOTAL_FAMILIA = re.compile(
    r"^\s*([A-Za-zÀ-ú][^\s\d]*)\s+(Mesa\s+de\s+Energia|Derivativos|Garantia\s+Firme|Garantias|Cr[eé]dito|Fian[cç]a)\b",
    re.IGNORECASE)


def _celulas_da_linha_total(ln, fim_rotulo) -> List[float]:
    """Celulas numericas depois do rotulo; celula de tabulacao com varios
    numeros separados por espaco ('351,5 1,5') conta cada um; celula com
    texto ('PFE zerando em 30 meses') nao conta."""
    resto = ln[fim_rotulo:]
    partes = resto.split("\t") if "\t" in resto else [resto]
    out = []
    for p in partes:
        toks = [t.strip().rstrip(":;.") for t in p.split()]
        toks = [t for t in toks if t]
        if not toks or not all(_RE_CEL_NUM.fullmatch(t) for t in toks):
            continue
        for t in toks:
            out.append(0.0 if t == "-" else (_para_float(t.replace("o", "0").replace("O", "0")) or 0.0))
    return out


def totais_propostos_do_quadro(fontes) -> List[Tuple[float, float, str, str, str]]:
    """[(proposta, atual, linha, tipo, texto_do_bloco)] das linhas de TOTAL cujo leiaute
    ATUAL | Risco | Proposta | Disp. esta' CONFIRMADO (Disp. = Proposta -
    Risco, ou cabecalho do bloco com as quatro colunas). tipo = 'GERAL', ou
    'FAMILIA' quando o bloco nao tem linha GERAL e tem UMA so' linha de total
    de familia. Blocos com produto fora do escopo (revolvencia, custodia...)
    nao entram."""
    import quadro_reader as qr
    out = []
    for _rot, tx in fontes or []:
        for bloco in qr.extrair_blocos_quadro(tx):
            esc = bloco.escala
            if esc is None:
                continue
            esc = float(esc)
            if fora_do_escopo_no_quadro([("bloco", bloco.texto)]):
                continue
            linhas = bloco.texto.split("\n")
            gerais = [(ln, fim, "GERAL") for ln, fim in linhas_total_geral(bloco.texto)]
            fams = [(ln, _RE_TOTAL_FAMILIA.match(ln).end(), "FAMILIA") for ln in linhas
                    if _RE_TOTAL_FAMILIA.match(ln)]
            alvo = gerais if gerais else (fams if len(fams) == 1 else [])
            cab = _sem_acento(bloco.texto[:600]).lower()
            cab_ok = all(k in cab for k in ("atual", "risco", "proposta", "disp"))
            for ln, fim, tipo in alvo:
                cel = [v * esc for v in _celulas_da_linha_total(ln, fim)]
                if len(cel) != 4:
                    continue
                resol = esc * 0.1
                if abs(cel[2] - cel[1] - cel[3]) <= max(resol, 0.005 * abs(cel[2]), 1000.0) or cab_ok:
                    out.append((cel[2], cel[0], re.sub(r"\s+", " ", ln.strip())[:120], tipo, bloco.texto))
    return out


# ---------------------------------------------------------------- R40 F08
# Conflito entre o total declarado na coluna PROPOSTA do termsheet e um
# "Limite Global" explicitamente rotulado em outro quadro/resumo do MESMO
# documento/escopo.  Importante: esta leitura e' puramente documental; nao
# recebe nem consulta o valor do sistema.  A tolerancia de comparacao de
# cadastro (R$1 mil OU 0,5%) nao resolve uma contradicao interna da fonte.
_RE_LIMITE_GLOBAL_EXPLICITO = re.compile(
    r"\blimite\s+global\b[^\n\r]{0,80}?(?:r\$|brl)\s*"
    r"([0-9]{1,3}(?:\.[0-9]{3})*(?:,[0-9]+)?|[0-9]+(?:[.,][0-9]+)?)\s*"
    r"(bi|bilh(?:ao|oes)|mm|milh(?:ao|oes))\b", re.IGNORECASE)


def _numero_monetario_rotulado(bruto: str, unidade: str) -> Optional[float]:
    x = str(bruto).strip()
    try:
        if "," in x:
            x = x.replace(".", "").replace(",", ".")
        elif re.fullmatch(r"\d{1,3}(?:\.\d{3})+", x):
            x = x.replace(".", "")
        v = float(x)
    except (TypeError, ValueError):
        return None
    u = _sem_acento(str(unidade)).casefold()
    mult = 1e9 if u.startswith("bi") else 1e6
    return v * mult


# R40-REC (F08, reconstrucao): o rotulo "Limite Global" so' e' o global
# PROPOSTO/aprovado do grupo quando nao vem qualificado como valor corrente
# ("limite global atual/vigente/anterior") nem restrito a uma familia/produto
# ("Limite Global Derivativos: R$ 125 MM" e' o teto da familia). "de R$ X para
# R$ Y" declara Y como o novo global.
_RE_QUALIF_CORRENTE = re.compile(r"\b(?:atual|atuais|vigente|anterior|existente|vencid[oa]|hoje|corrente)\b")
_RE_QUALIF_FAMILIA = re.compile(
    r"^\s*(?:de\s+|para\s+|d[aoe]s?\s+)?(?:derivativ|garantia|fian|credito|cambio|mesa|swap|ndf|"
    r"opera|produto|linha|custodia|cpr|cdca|cri|cra|debent)", re.IGNORECASE)
_RE_PARA_NOVO = re.compile(
    r"^\s*(?:para|->|→)\s*(?:r\$|brl)\s*([0-9]{1,3}(?:\.[0-9]{3})*(?:,[0-9]+)?|[0-9]+(?:[.,][0-9]+)?)\s*"
    r"(bi|bilh(?:ao|oes)|mm|milh(?:ao|oes))\b", re.IGNORECASE)


def _qualificador_do_global(meio: str) -> Optional[str]:
    """Texto entre 'limite global' e o numero -> motivo para NAO usar como
    global proposto do grupo (None = rotulo limpo)."""
    m0 = _sem_acento(str(meio or "")).lower()
    if _RE_QUALIF_CORRENTE.search(m0):
        return "valor corrente/anterior, não o proposto"
    if _RE_QUALIF_FAMILIA.match(m0.strip(" :-")):
        return "global de família/produto, não do grupo"
    return None


def limites_globais_explicitamente_rotulados(fontes) -> List[Tuple[float, float, str, str]]:
    """[(valor_rs, resolucao_rs, trecho, rotulo_fonte)] para Limite Global.

    A resolucao vem da grafia: ``54 MM`` tem passo de R$1 MM; ``53,6 MM``
    tem passo de R$0,1 MM. Isso permite distinguir arredondamento declarado
    de contradicao aritmetica real sem consultar o sistema.
    """
    out = []
    vistos = set()
    for rot, tx in fontes or []:
        for m in _RE_LIMITE_GLOBAL_EXPLICITO.finditer(tx or ""):
            _meio = (tx or "")[m.start():m.start(1)]
            _meio = re.sub(r"^\s*limite\s+global", "", _sem_acento(_meio), flags=re.IGNORECASE)
            _meio = re.sub(r"(?:r\$|brl)\s*$", "", _meio, flags=re.IGNORECASE)
            if _qualificador_do_global(_meio):
                continue
            _novo = _RE_PARA_NOVO.match((tx or "")[m.end():m.end() + 60])
            if _novo:
                v = _numero_monetario_rotulado(_novo.group(1), _novo.group(2))
                bruto, unid = str(_novo.group(1)), _novo.group(2)
            else:
                v = _numero_monetario_rotulado(m.group(1), m.group(2))
                bruto, unid = str(m.group(1)), m.group(2)
            if v is None or v <= 0:
                continue
            dec = len(bruto.split(",", 1)[1]) if "," in bruto else (len(bruto.split(".", 1)[1]) if bruto.count(".") == 1 else 0)
            u = _sem_acento(str(unid)).casefold()
            passo = (1e9 if u.startswith("bi") else 1e6) * (10 ** (-dec))
            chave = round(v, 2)
            if chave in vistos:
                continue
            vistos.add(chave)
            trecho = re.sub(r"\s+", " ", m.group(0)).strip()[:160]
            out.append((v, passo, trecho, str(rot)[:120]))
    return out


_RE_MANUTENCAO_LIMITE = re.compile(
    r"mesmas\s+condic|manutencao\s+d[oa]s?\s+(?:limite|condic)|mantid[oa]s?\s+(?:o\s+|os\s+)?(?:limite|valor)|"
    r"sem\s+alterac\w*\s+(?:de|do|no)\s+(?:limite|valor)")
_GENERICOS_ROTULO = {"GRUPO", "BANCO", "FIDC", "FUNDO", "HOLDING", "PARTICIPACOES", "COMPANHIA", "BRASIL",
                     "LTDA", "S/A", "INDUSTRIA", "COMERCIO", "ENERGIA", "USINA", "AGRICOLA", "SERVICOS", "BRL",
                     "TRADING", "CONSTRUTORA", "ALIMENTOS", "DISTRIBUIDORA", "INVESTIMENTOS", "CAPITAL"}
_RE_ROTULO_QUADRO = re.compile(r"^\s*([^|\t\n]{3,90}?)\s*\|\s*(?:BRL|R\$)", re.IGNORECASE | re.MULTILINE)


def _tokens_nome(s) -> Set[str]:
    t = re.sub(r"[^A-Z0-9]+", " ", _sem_acento(str(s or "")).upper()).split()
    return {x for x in t if len(x) >= 4 and x not in _GENERICOS_ROTULO}


def rotulo_do_quadro(bloco_texto: str) -> Optional[str]:
    """Entidade que o CABECALHO do quadro nomeia ('SEVAFUMO | BRL MM ...')."""
    cab = "\n".join(str(bloco_texto or "").split("\n")[:3])
    m = _RE_ROTULO_QUADRO.search(cab)
    return m.group(1).strip() if m else None


def quadro_de_outra_entidade(bloco_texto: str, nomes) -> bool:
    """R41 (ata multigrupo): bloco cujo cabecalho nomeia OUTRA entidade nao
    pertence ao escopo do grupo, mesmo que esteja dentro do recorte da secao
    (na ata consolidada os quadros de todas as secoes vem juntos, como
    imagens). Sem nomes ou sem rotulo -> nao exclui (comportamento anterior)."""
    if not nomes:
        return False
    rot = rotulo_do_quadro(bloco_texto)
    if not rot:
        return False
    tr = _tokens_nome(rot)
    if not tr:
        return False
    tn = set()
    for n in nomes:
        tn |= _tokens_nome(n)
    return bool(tn) and not (tr & tn)


_RE_LINHA_DECISAO = re.compile(r"decis[aã]o\s*:[^\n]{0,300}", re.IGNORECASE)
_RE_CONFORME_PROPOSTO = re.compile(r"conforme\s+(?:o\s+)?propost", re.IGNORECASE)


def limites_da_decisao_conforme_proposto(fontes) -> List[Tuple[float, float, str, str]]:
    """[(valor_rs, resolucao, trecho, rotulo)] dos limites declarados em linha
    'Decisao: Aprovado conforme proposto ... Limite R$ X' (aprovacao integral
    com valor literal). Linha de decisao sem 'conforme proposto' NAO entra: o
    comite pode aprovar valor diferente do proposto (isso nao e' contradicao)."""
    from normalize import parse_limite_da_decisao
    out, vistos = [], set()
    for rot, tx in fontes or []:
        for m in _RE_LINHA_DECISAO.finditer(tx or ""):
            ln = m.group(0)
            if not _RE_CONFORME_PROPOSTO.search(ln):
                continue
            pv = parse_limite_da_decisao(ln)
            if pv.valor_rs is None:
                continue
            v = float(pv.valor_rs)
            lit = str(pv.expressao_literal or "")
            num = re.search(r"(\d[\d.,]*)\s*(mm|m|mil|milh\w*|bi\w*)?", lit.split("$")[-1] if "$" in lit else lit,
                            re.IGNORECASE)
            dec = 0
            if num and "," in num.group(1):
                dec = len(num.group(1).split(",", 1)[1])
            u = (num.group(2) or "mm").lower() if num else "mm"
            passo = (1e9 if u.startswith("bi") else 1e3 if u.startswith("mil") else 1e6) * (10 ** (-dec))
            if round(v, 2) in vistos:
                continue
            vistos.add(round(v, 2))
            out.append((v, passo, re.sub(r"\s+", " ", ln).strip()[:160], str(rot)[:120]))
    return out


_RE_PROPOSTA_LINHA = re.compile(r"(?:^|\n)\s*proposta\s*:[^\n]{0,600}", re.IGNORECASE)
_RE_VALOR_MONETARIO = re.compile(r"(?:r\$|brl|us\$|usd)\s*\d", re.IGNORECASE)
_RE_TOTAL_DA_PROPOSTA = re.compile(r"(?:valor\s+)?total\s+(?:de|em)\s+((?:r\$|brl)\s*[\d.,]+\s*(?:mm|mi\b|milh\w*|bi\b|bilh\w*))",
                                   re.IGNORECASE)


_RE_RETIFICA = re.compile(r"(?:retifica|errata|onde\s+se\s+l[eê]|leia-se|corrigindo\s+o\s+valor)[^\n]{0,200}", re.IGNORECASE)


def _retificacao_declarada(fontes) -> Optional[Tuple[float, str]]:
    """R44: valor declarado numa linha de RETIFICACAO/ERRATA do documento
    ("onde se le R$ 140 MM, leia-se R$ 145 MM" -> o ultimo valor)."""
    from normalize import parse_valor_com_qualificador
    for _rot, tx in fontes or []:
        for m in _RE_RETIFICA.finditer(str(tx or "")):
            vals = re.findall(r"(?:r\$|brl)\s*[\d.,]+\s*(?:mm|mi\b|milh\w*|bi\b|bilh\w*)", m.group(0), re.IGNORECASE)
            if vals:
                pv = parse_valor_com_qualificador(vals[-1], "BRL_milhoes")
                if pv.valor_rs is not None:
                    return float(pv.valor_rs), re.sub(r"\s+", " ", m.group(0)).strip()[:200]
    return None




def retificacao_vinculada(fontes) -> Optional[Tuple[float, float, str]]:
    """R50: errata/retificação vinculada positivamente à mesma decisão.

    Compatibilidade de valores e mesmo grupo, isoladamente, não provam vínculo.
    É necessário ao menos um elo positivo: mesma operação nomeada, identificador
    decisório/CNPJ comum, ou thread/assunto claramente correspondente. Conflito
    explícito de operação/identificador bloqueia a substituição. Uma errata
    autônoma só é aceita quando ela própria referencia inequivocamente a decisão
    anterior (ex.: "e-mail anterior") e identifica a operação/assunto.
    """
    from normalize import parse_valor_com_qualificador
    try:
        from registro_repetido import identidade_operacao
    except Exception:
        identidade_operacao = lambda _x: {}

    lit = r"((?:r\$|brl)\s*[\d.,]+\s*(?:mm|mi\b|milh\w*|bi\b|bilh\w*))"
    re_marcador = re.compile(r"\b(errata|retifica(?:ç[aã]o|r|do|da)?|corrig(?:ir|e|indo|ido|ida)|houve\s+um\s+erro)\b", re.I)
    re_ref_anterior = re.compile(
        r"\b(?:e-?mail|mensagem|proposta|pedido|decis[aã]o|documento|material)\s+(?:imediatamente\s+)?anterior\b"
        r"|\b(?:onde\s+se\s+l[eê]|leia-se|em\s+vez\s+de|e\s+n[aã]o\s+de)\b", re.I)
    re_oper = re.compile(r"\bopera[cç][aã]o\s+(?:da\s+|do\s+)?([A-ZÀ-Ú0-9][A-ZÀ-Ú0-9 _./-]{1,80})", re.I)
    re_cnpj = re.compile(r"(?<!\d)(\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2})(?!\d)")
    padroes = [
        (re.compile(r"(?:corret[oa]|corrigid[oa]|limite[^\n]{0,50}?(?:correto|a\s+ser\s+aprovado)[^\n]{0,40}?)\D{0,20}" + lit +
                    r"[^\n]{0,100}?(?:e\s+n[aã]o\s+(?:de\s+)?|em\s+vez\s+de\s+)" + lit, re.I), "novo_antigo"),
        (re.compile(r"onde\s+se\s+l[eê][^\n]{0,30}?" + lit + r"[^\n]{0,80}?leia-se[^\n]{0,30}?" + lit, re.I), "antigo_novo"),
        (re.compile(r"(?:retifica[^\n]{0,80}|errata[^\n]{0,80})\bde\s+" + lit + r"[^\n]{0,40}?\bpara\s+" + lit, re.I), "antigo_novo"),
    ]

    def _pv(x):
        q = parse_valor_com_qualificador(x, "BRL_milhoes")
        return float(q.valor_rs) if q.valor_rs is not None else None

    def _norm(x):
        return re.sub(r"[^A-Z0-9]+", " ", _sem_acento(str(x)).upper()).strip()

    def _ops(tx):
        out = set()
        for m in re_oper.finditer(str(tx or "")):
            v = _norm(m.group(1))
            # corta qualificadores/frases depois do nome da operação
            v = re.split(r"\b(?:ONDE|COM|CUJO|QUE|PARA|NO|NA|E\s+O|E\s+A)\b", v, maxsplit=1)[0].strip()
            if v and v not in {"COM VALORES CORRIGIDOS", "COM OS VALORES CORRIGIDOS"}:
                out.add(v)
        return out

    def _thread_tokens(rot):
        n = _norm(rot)
        toks = [t for t in n.split() if len(t) >= 4 and t not in {
            "FAST", "TRACK", "ERRATA", "RESP", "RE", "RES", "MSG", "NIVEL"
        }]
        return set(toks)

    def _ids(tx):
        d = identidade_operacao(str(tx or "")) or {}
        return {k: set(v) for k, v in d.items() if k not in {"cnpj", "cpf"}}

    fontes = list(fontes or [])
    candidatos = []
    for i, (rot, tx) in enumerate(fontes):
        tx = str(tx or "")
        if not re_marcador.search(f"{rot or ''}\n{tx}"):
            continue
        for rx, ordem in padroes:
            m = rx.search(tx)
            if not m:
                continue
            a, b = _pv(m.group(1)), _pv(m.group(2))
            if a is None or b is None or abs(a-b) <= max(1000.0, 0.001*max(abs(a), abs(b))):
                continue
            antigo, novo = (a, b) if ordem == "antigo_novo" else (b, a)
            candidatos.append((i, str(rot or ""), tx, m, antigo, novo))

    for i, rot, tx, m, antigo, novo in candidatos:
        bases = [(j, str(r or ""), str(t or "")) for j, (r, t) in enumerate(fontes)
                 if j != i and not re_marcador.search(f"{r or ''}\n{t or ''}")]
        ops_e = _ops(f"{rot}\n{tx}")
        ids_e = _ids(tx)
        cnpj_e = {re.sub(r"\D", "", x) for x in re_cnpj.findall(tx)}
        th_e = _thread_tokens(rot)
        positivo = False
        conflito = False

        for _j, rb, tb in bases:
            ops_b = _ops(f"{rb}\n{tb}")
            ids_b = _ids(tb)
            cnpj_b = {re.sub(r"\D", "", x) for x in re_cnpj.findall(tb)}
            # operação explicitamente diferente é conflito, não mero silêncio.
            if ops_e and ops_b and not (ops_e & ops_b):
                conflito = True
                continue
            for tipo in set(ids_e) & set(ids_b):
                if ids_e[tipo] and ids_b[tipo]:
                    if ids_e[tipo] & ids_b[tipo]:
                        positivo = True
                    elif ids_e[tipo] != ids_b[tipo]:
                        conflito = True
            if ops_e & ops_b:
                positivo = True
            if cnpj_e and cnpj_b and (cnpj_e & cnpj_b):
                positivo = True
            th_b = _thread_tokens(rb)
            if len(th_e & th_b) >= 3 and len(th_e & th_b) >= max(3, min(len(th_e), len(th_b)) // 2):
                positivo = True

        if conflito and not positivo:
            continue
        if not bases:
            # Caso autocontido: a própria errata precisa declarar o elo com a
            # decisão anterior e identificar a operação/assunto.
            positivo = bool(re_ref_anterior.search(tx) and (ops_e or len(th_e) >= 2))
        elif not positivo:
            # Mesmo processo sem identificador forte: só aceita referência
            # explícita ao anterior se houver UMA única operação-base possível.
            ops_base = set().union(*[_ops(f"{rb}\n{tb}") for _, rb, tb in bases]) if bases else set()
            if re_ref_anterior.search(tx) and len(ops_base) <= 1 and not (ops_e and ops_base and not (ops_e & ops_base)):
                # Exige também continuidade clara de thread; grupo sozinho não basta.
                positivo = any(len(th_e & _thread_tokens(rb)) >= 3 for _, rb, _ in bases)
        if not positivo:
            continue
        trecho = re.sub(r"\s+", " ", m.group(0)).strip()[:220]
        return antigo, novo, f"{rot[:100]}: {trecho}"
    return None


def tranches_cumulativas(fontes) -> Optional[Tuple[float, float, float, str]]:
    """R50: soma tranches somente com vínculo positivo da mesma operação.

    A presença textual de "1ª tranche" e "2ª tranche" não basta. Quando há
    âncoras explícitas de operação/linha/contrato, elas precisam coincidir.
    Sem âncora repetida, aceita-se apenas continuidade textual inequívoca da
    mesma linha ("essa nova", "mesma linha", "complementa a primeira").
    Cancelamento/substituição/superação bloqueiam a soma.
    """
    from normalize import parse_valor_com_qualificador
    try:
        from registro_repetido import identidade_operacao
    except Exception:
        identidade_operacao = lambda _x: {}

    lit = r"((?:r\$|brl)\s*[\d.,]+\s*(?:mm|mi\b|milh\w*|bi\b|bilh\w*))"
    re_subst = re.compile(r"\b(?:substitu\w*|em\s+substitui[cç][aã]o|cancela\w*|cancelad[ao]|revoga\w*|revogad[ao]|superad[ao]|no\s+lugar\s+d[aeo]|ao\s+inv[eé]s\s+d[aeo]|deixa\s+de\s+vigorar)\b", re.I)
    p1 = [
        re.compile(r"(?:aprov\w*[^\n.]{0,120}?)?" + lit + r"[^\n.]{0,120}?(?:1\s*[ªaºo]?\s*tranche|primeira\s+tranche)", re.I),
        re.compile(r"(?:1\s*[ªaºo]?\s*tranche|primeira\s+tranche)[^\n.]{0,120}?" + lit, re.I),
    ]
    p2 = [
        re.compile(r"(?:essa\s+nova|nova\s+tranche|adicional|acr[eé]scimo)?[^\n.]{0,100}?" + lit + r"[^\n.]{0,100}?(?:2\s*[ªaºo]?\s*tranche|segunda\s+tranche)", re.I),
        re.compile(r"(?:2\s*[ªaºo]?\s*tranche|segunda\s+tranche)[^\n.]{0,120}?" + lit, re.I),
    ]
    re_op = re.compile(r"\bopera[cç][aã]o\s+([A-ZÀ-Ú0-9][A-ZÀ-Ú0-9 _./]{1,60}?)(?=\s*[:;|\n])", re.I)
    re_linha = re.compile(r"\blinha\s+(?:com\s+(?:o|a)\s+|da\s+|do\s+|de\s+)?([A-Z][A-Z0-9._/-]{2,})", re.I)

    def _pv(x):
        q = parse_valor_com_qualificador(x, "BRL_milhoes")
        return float(q.valor_rs) if q.valor_rs is not None else None

    def _norm(x):
        return re.sub(r"[^A-Z0-9]+", "", _sem_acento(str(x)).upper())

    def _ancora_antes(texto, pos):
        ini = max(0, pos - 240)
        trecho = texto[ini:pos]
        hits = []
        for rx, tipo in ((re_op, "operacao"), (re_linha, "linha")):
            for m in rx.finditer(trecho):
                hits.append((m.end(), tipo, _norm(m.group(1))))
        if hits:
            _e, tipo, val = max(hits, key=lambda z: z[0])
            return tipo, val
        # IDs estruturados no contexto local (contrato/CCB/deal/ticket etc.)
        ids = identidade_operacao(trecho) or {}
        for tipo in ("contrato", "proposta", "emissao", "serie", "veiculo"):
            vals = ids.get(tipo) or set()
            if len(vals) == 1:
                return tipo, next(iter(vals))
        return None

    for rot, tx in fontes or []:
        plano = re.sub(r"[ \t]+", " ", str(tx or ""))
        m1 = next((rx.search(plano) for rx in p1 if rx.search(plano)), None)
        m2 = next((rx.search(plano) for rx in p2 if rx.search(plano)), None)
        if not m1 or not m2:
            continue
        v1, v2 = _pv(m1.group(1)), _pv(m2.group(1))
        if v1 is None or v2 is None or v1 <= 0 or v2 <= 0:
            continue
        a, b = min(m1.start(), m2.start()), max(m1.end(), m2.end())
        janela = plano[max(0, a-180):min(len(plano), b+200)]
        if not re.search(r"\b(?:essa\s+nova|nova\s+tranche|segunda\s+tranche|adicional|continu\w*|al[eé]m\s+d[aeo]|somad[ao]|cumulativ\w*|complementa\w*|mesma\s+linha)\b", janela, re.I):
            continue
        # Linguagem de substituição/cancelamento só bloqueia quando pertence
        # à relação entre as tranches; palavras homônimas fora desse trecho
        # (ex.: cargo "Diretor Substituto") não têm efeito.
        janela_subst = plano[m1.start():min(len(plano), m2.end() + 120)]
        if re_subst.search(janela_subst):
            continue

        anc1, anc2 = _ancora_antes(plano, m1.start()), _ancora_antes(plano, m2.start())
        if anc1 and anc2:
            if anc1 != anc2:
                continue
            vinculo = f"mesma {anc1[0]} {anc1[1]}"
        elif anc1 or anc2:
            # Uma âncora só pode ser herdada pela segunda frase quando há
            # referência anafórica explícita à tranche/linha imediatamente anterior.
            entre = plano[m1.end():m2.start()+80]
            if not re.search(r"\b(?:essa\s+nova|mesma\s+linha|complementa\w*\s+(?:a\s+)?primeira|segunda\s+tranche\s+(?:da|desta)\s+mesma)\b", entre, re.I):
                continue
            vinculo = f"continuidade explícita da {anc1 or anc2}"
        else:
            # Sem identificador nominal, exige linguagem inequívoca de que a
            # segunda tranche continua/complementa a mesma linha anterior.
            if not re.search(r"\b(?:essa\s+nova[^.]{0,100}(?:mesma\s+linha|continu)|mesma\s+linha|complementa\w*\s+(?:a\s+)?primeira)\b", janela, re.I):
                continue
            vinculo = "continuidade explícita da mesma linha"

        trecho = re.sub(r"\s+", " ", janela).strip()[:320]
        return v1, v2, v1 + v2, f"{str(rot)[:100]}: {vinculo}; {trecho}"
    return None


def total_da_proposta_da_decisao(fontes, trecho_decisao: str) -> Optional[Tuple[float, str]]:
    """R42 (PALIFAMO 'nao somou direito os valores do termsheet'): o total
    declarado na linha 'Proposta:' IMEDIATAMENTE anterior a linha de decisao
    (mesma secao). So' conta se a linha de proposta traz UM unico valor
    monetario e ele e' rotulado como total ('valor total de R$ X')."""
    from normalize import parse_valor_com_qualificador
    alvo = re.sub(r"\s+", " ", str(trecho_decisao or "")).strip()[:80]
    if not alvo:
        return None
    for _rot, tx in fontes or []:
        tx = str(tx or "")
        plano = re.sub(r"[ \t]+", " ", tx)
        k = plano.find(alvo)
        if k < 0:
            continue
        props = list(_RE_PROPOSTA_LINHA.finditer(plano[:k]))
        if not props:
            continue
        ln = props[-1].group(0)
        # outra linha de decisao entre a proposta e a decisao = outra secao
        if _RE_LINHA_DECISAO.search(plano[props[-1].end():k]):
            continue
        if len(_RE_VALOR_MONETARIO.findall(ln)) != 1:
            continue
        m = _RE_TOTAL_DA_PROPOSTA.search(ln)
        if not m:
            continue
        pv = parse_valor_com_qualificador(m.group(1), "BRL_milhoes")
        if pv.valor_rs is None:
            continue
        return float(pv.valor_rs), re.sub(r"\s+", " ", ln).strip()[:200]
    return None


def conflito_total_documental(fontes, nomes=None) -> Optional[dict]:
    """Detecta contradicao interna TOTAL PROPOSTA x Limite Global narrativo.

    Retorna None se nao houver prova estrutural suficiente. Quando ha' um
    unico total Proposta do quadro e um unico Limite Global explicitamente
    rotulado, valores materialmente distintos sao preservados como conflito
    documental. Nao substitui nenhum deles e nao usa tolerancia de cadastro.
    R40-REC: global qualificado como corrente/de familia nao conta; global
    igual ao total ATUAL do quadro e' o limite corrente (nao contradiz a
    proposta). R41: quadro rotulado para OUTRA entidade nao conta (`nomes`).
    """
    totais = [t for t in totais_propostos_do_quadro(fontes) if not quadro_de_outra_entidade(t[4], nomes)]
    atuais = [float(t[1]) for t in totais if t[1] is not None]
    props = {}
    for prop, _atual, linha, tipo, _bloco in totais:
        # R40-REC: o "Limite Global" narrativo e' do GRUPO; so' o total GERAL
        # do quadro pode contradize-lo. Total de UMA familia (quadro so' da
        # familia alterada) e' outro nivel, nao contradicao (SAGIJIJA).
        if tipo != "GERAL":
            continue
        props.setdefault(round(float(prop), 2), (float(prop), linha, tipo))
    if len(props) != 1:
        return None
    globs = {}
    for v, resol, trecho, rot in limites_globais_explicitamente_rotulados(fontes):
        globs.setdefault(round(float(v), 2), (float(v), float(resol), trecho, rot))
    # R41 (B4, PALIFAMO): a linha de DECISAO que aprova "conforme proposto" e
    # declara outro limite contradiz o total Proposta do mesmo quadro tanto
    # quanto um "Limite Global" narrativo. Valor da decisao igual a uma celula
    # do quadro (subtotal de familia/linha) e' decisao de componente, nao
    # contradicao.
    _blocos_tot = [t[4] for t in totais if t[3] == "GERAL"]
    _de_decisao = set()
    for v, resol, trecho, rot in limites_da_decisao_conforme_proposto(fontes):
        if any(componente_do_quadro(b, v, "") for b in _blocos_tot):
            continue
        if round(float(v), 2) not in globs:
            _de_decisao.add(round(float(v), 2))
        globs.setdefault(round(float(v), 2), (float(v), float(resol), trecho, rot))
    if len(globs) != 1:
        return None
    prop, linha, tipo = next(iter(props.values()))
    glob, resol_glob, trecho, rot = next(iter(globs.values()))
    # Um numero narrativo menos preciso pode ser apenas a forma arredondada
    # do total tabular (ex.: 54 MM versus 53,6 MM). Aceita-se no maximo meia
    # unidade da precisao DECLARADA. Isso e' diferente da tolerancia de negocio.
    # JOPUSELU 471 MM x 472 MM excede meia unidade e permanece conflito.
    margem_grafia = max(1000.0, 0.5 * resol_glob + 1.0)
    if abs(prop - glob) <= margem_grafia:
        return None
    # R40-REC: o "Limite Global" narrativo igual ao total ATUAL do mesmo
    # quadro e' o limite corrente citado no resumo, nao contradiz a proposta
    # Excecao: o proprio documento diz que o limite e' MANTIDO ("renovacao nas
    # mesmas condicoes", "manutencao do limite") e o quadro propoe outro total
    # - ai' a narrativa contradiz o quadro e o conflito fica (MAMAGOSU).
    _manut = any(_RE_MANUTENCAO_LIMITE.search(_sem_acento(str(tx or "")).lower()) for _r, tx in fontes or [])
    if not _manut and any(abs(a - glob) <= margem_grafia for a in atuais):
        return None
    # R44 (A08, parecer R43 - substitui o "B4 refinado" da R42): a linha
    # 'Proposta:' e o quadro sao DUAS representacoes da MESMA proposta, nao
    # duas decisoes; maioria de fontes nao resolve decisao x proposta. So'
    # uma RETIFICACAO/ERRATA expressa no documento, que declare o valor,
    # resolve; sem ela o conflito documental fica (nenhum valor escolhido).
    _ret = _retificacao_declarada(fontes)
    if round(glob, 2) in _de_decisao and _ret is not None:
        _vr, _tr = _ret
        if abs(_vr - prop) <= 1000.0 or abs(_vr - glob) <= 1000.0:
            return {
                "resolvido": True,
                "valor_aprovado_rs": _vr,
                "valor_decisao_rs": glob,
                "valores": [_vr],
                "linha_total": linha,
                "tipo_total": tipo,
                "trecho_global": trecho,
                "trecho_proposta": _tr,
                "fonte_global": rot,
                "motivo": (f"o documento retifica expressamente o valor ('{_tr[:90]}'): R$ {_vr / 1e6:,.1f} MM; "
                           f"a linha de decisão declarava R$ {glob / 1e6:,.1f} MM e o quadro R$ {prop / 1e6:,.1f} MM "
                           "(R44)"),
            }
    _tp = total_da_proposta_da_decisao(fontes, trecho) if round(glob, 2) in _de_decisao else None
    _nota_prop = (f"; a linha 'Proposta:' da seção declara R$ {_tp[0] / 1e6:,.1f} MM - é a mesma proposta do quadro, "
                  "não uma segunda decisão (R44)") if _tp is not None else ""
    return {
        "total_proposta_rs": prop,
        "limite_global_narrativo_rs": glob,
        "valores": [glob, prop],
        "linha_total": linha,
        "tipo_total": tipo,
        "trecho_global": trecho,
        "fonte_global": rot,
        "motivo": (f"conflito documental: total Proposta do quadro = R$ {prop / 1e6:,.3f} MM, "
                   f"mas o documento declara {trecho}; preservar ambos, sem escolher pelo sistema{_nota_prop}"),
    }


def componente_do_quadro(bloco: str, valor: float, linha_total: str, esc_tol: float = 1000.0) -> bool:
    """O valor aparece como celula de OUTRA linha do bloco (subtotal de
    familia, item)? Ex.: JF ZALOFIGU - 115,0 e' o total de derivativos."""
    import quadro_reader as qr
    for ln in bloco.split("\n"):
        if re.sub(r"\s+", " ", ln.strip())[:120] == linha_total:
            continue
        for v in qr.ler_celulas_numericas(ln) or []:
            for esc in (1e6, 1e3, 1.0):
                if abs(v * esc - valor) <= max(esc_tol, 0.001 * abs(valor)):
                    return True
    return False


def fora_do_escopo_no_quadro(fontes) -> List[str]:
    """Evidencias de produto FORA DO ESCOPO com valor dentro do quadro do
    limite: ['<produto>: <trecho>'] (vazio = nenhuma evidencia)."""
    out, vistos = [], set()
    for _rot, tx in fontes or []:
        for bl in blocos_de_quadro(tx):
            for ln in bl.split("\n")[1:]:
                # linha de indicador financeiro no mesmo bloco de OCR (quadro de
                # "Highlights" colado ao termsheet: 'Margem EBIT 9,2% ... VEND')
                # nao e' linha de limite (caso GRUPO SOGADOCU)
                if "%" in ln or _FINANCEIRO.search(ln):
                    continue
                for m in _FORA_ESCOPO_QUADRO.finditer(ln):
                    resto = ln[m.end():]
                    if re.match(r"\s*:", resto):          # cabecalho de outro limite
                        continue
                    if not re.search(r"\d", resto):
                        continue
                    if re.match(r"\s*(?:n\.?\s*/?\s*a\.?|-)\s*$", resto, re.IGNORECASE):
                        continue
                    prod = _sem_acento(m.group(0)).lower()
                    chave = prod[:6]
                    if chave in vistos:
                        continue
                    vistos.add(chave)
                    trecho = re.sub(r"\s+", " ", ln.strip())[:90]
                    out.append(f"{m.group(0)}: '{trecho}'")
    return out


_RE_CEL_LINHA = re.compile(r"\d{1,3}(?:\.\d{3})+(?:,\d+)?|\d+(?:,\d+)?")


def _celulas_da_linha(ln) -> List[float]:
    """Celulas numericas (inteiras) da linha do quadro, na escala do quadro.
    Celula com texto ("2 anos", "[56.944.323/0001-98]") nao conta."""
    partes = ln.split("\t") if "\t" in ln else ln.split()
    out = []
    for p in partes:
        p = p.strip().rstrip(":;.")
        if p and _RE_CEL_LINHA.fullmatch(p):
            v = _para_float(p)
            if v is not None:
                out.append(v)
    return out


def parcela_fora_do_escopo(fontes, valor_ata, valor_sistema, tol_abs=1000.0, tol_rel=0.005):
    """R37 (auditoria da R35, caso BANCO GUDAGELO): o limite global da ata e'
    o TOTAL GERAL de um quadro que inclui produto FORA do escopo do sistema
    (revolvencia, custodia, compromissada, FGC, LF...), mesmo quando a
    extracao so' registrou os produtos do escopo.

    Devolve None (nenhum quadro cujo TOTAL GERAL = ata tem produto fora do
    escopo) ou (demonstrado, valor_fora, trecho):
      demonstrado=True  -> existe no quadro um item/subtotal fora do escopo de
                           valor V com ata - V = sistema (parcela comparavel
                           = sistema, falso positivo de escopo);
      demonstrado=False -> ha' produto fora do escopo dentro do total, mas a
                           conta nao fecha (a comparacao nao e' demonstravel).
    """
    if valor_ata is None or valor_sistema is None:
        return None
    valor_ata, valor_sistema = float(valor_ata), float(valor_sistema)
    import quadro_reader as qr
    ok = lambda a, b: abs(a - b) <= max(tol_abs, tol_rel * abs(b))
    presente = None
    for _rot, tx in fontes or []:
        for bloco in qr.extrair_blocos_quadro(tx):
            esc = bloco.escala
            if esc is None:
                continue
            esc = float(esc)
            ls = bloco.texto.split("\n")
            tot = [ln for ln in ls if _RE_GERAL.match(ln)]
            if not tot or not any(ok(v * esc, valor_ata) for ln in tot for v in (celulas_cruas(ln) or [])):
                continue                              # o total deste quadro nao e' a ata
            # R38 (auditoria da R37, P03: Atual 1.200 x Proposta 1.000): a
            # parcela fora do escopo vem da MESMA coluna deliberada do total
            # (Proposta), nunca da celula que "fecha a conta"
            col = None
            for ln in tot:
                cel_t = [v * esc for v in _celulas_da_linha_total(ln, _RE_GERAL.match(ln).end())]
                idx = [i for i, v in enumerate(cel_t) if ok(v, valor_ata)]
                cab = _sem_acento(bloco.texto[:600]).lower()
                cab_ok = all(k in cab for k in ("atual", "risco", "proposta", "disp"))
                if len(cel_t) == 4 and (abs(cel_t[2] - cel_t[1] - cel_t[3]) <= max(esc * 0.1, 0.005 * abs(cel_t[2]))
                                        or cab_ok) and 2 in idx:
                    col = (2, 4)
                elif len(cel_t) == 2 and 1 in idx:
                    col = (1, 2)
                if col:
                    break
            fora = []
            for ln in ls:
                if _RE_GERAL.match(ln) or "%" in ln or _FINANCEIRO.search(ln):
                    continue
                m = _FORA_ESCOPO_QUADRO.search(ln)
                if not m or re.match(r"\s*:", ln[m.end():]):
                    continue
                cel = [v * esc for v in _celulas_da_linha(ln[m.end():])]
                if col is not None:
                    # so' a celula da coluna deliberada, em linha com o mesmo
                    # numero de colunas numericas do total
                    cel_i = [v * esc for v in _celulas_da_linha_total(ln, m.end())]
                    cel = [cel_i[col[0]]] if len(cel_i) == col[1] else []
                else:
                    cel = []
                if cel:
                    fora.append((m.group(0), cel, re.sub(r"\s+", " ", ln.strip())[:90]))
                elif m:
                    fora.append((m.group(0), [], re.sub(r"\s+", " ", ln.strip())[:90]))
            if not fora:
                continue
            for prod, cel, tr in fora:
                for v in cel:
                    if v > 0 and ok(valor_ata - v, valor_sistema):
                        return True, v, f"{prod}: '{tr}'"
            presente = presente or (False, None, f"{fora[0][0]}: '{fora[0][2]}'")
    return presente



def quadro_consolidado_grupo(fontes, grupo: str, valor: float,
                              tol_abs=1000.0, tol_rel=0.005) -> Optional[str]:
    """R50: prova positiva de quadro consolidado do grupo, confinada à
    MESMA seção documental.

    A identificação do grupo, o Limite Global, o quadro e a linha total usada
    precisam coexistir no mesmo bloco/seção semântica. Em documento com mais
    de um cabeçalho ``Grupo Econômico:``, nunca se combinam sinais entre as
    seções. Fontes já recortadas pelo motor continuam sendo tratadas como uma
    única seção quando não trazem cabeçalhos concorrentes.
    """
    if valor is None or not grupo:
        return None
    valor = float(valor)
    alvo = re.sub(r"[^A-Z0-9]+", " ", _sem_acento(str(grupo)).upper()).strip()
    if len(alvo) < 3:
        return None
    ok = lambda a, b: abs(a - b) <= max(tol_abs, tol_rel * abs(b))
    re_total = re.compile(
        r"^\s*(?:Jotecoga\s+)?(?:Total\s+)?(?:Banco\s+XP|XP|Geral|Consolidado)(?:\s+[^\t\d]{0,50})?",
        re.IGNORECASE,
    )
    re_global = re.compile(r"Limite\s+Global\s*:\s*(?:R\$|BRL)\s*[\d.,]+\s*(?:MM|MI|milh\w*|bi\w*)",
                           re.IGNORECASE)
    re_grupo = re.compile(r"(?im)^\s*Grupo\s+Econ[oô]mico\s*:\s*([^\n\r]+)")
    import quadro_reader as qr

    def _norm_nome(x):
        return re.sub(r"[^A-Z0-9]+", " ", _sem_acento(str(x)).upper()).strip()

    def _secoes(tx):
        ms = list(re_grupo.finditer(tx))
        if not ms:
            # O chamador normalmente já recorta atas consolidadas para a seção
            # do grupo. Sem cabeçalhos concorrentes, a fonte é a unidade
            # semântica disponível; ainda se exige o nome do grupo nela.
            return [tx] if alvo in _norm_nome(tx) else []
        out = []
        for i, m in enumerate(ms):
            nome = _norm_nome(m.group(1))
            if not (nome == alvo or nome.startswith(alvo + " ") or alvo.startswith(nome + " ")):
                continue
            fim = ms[i + 1].start() if i + 1 < len(ms) else len(tx)
            out.append(tx[m.start():fim])
        return out

    for rot, tx in fontes or []:
        tx = str(tx or "")
        for sec in _secoes(tx):
            norm = _norm_nome(sec)
            if alvo not in norm:
                continue
            glob_ok = False
            for m in re_global.finditer(sec):
                vals = valores_monetarios(m.group(0))
                if vals and any(ok(v[0], valor) for v in vals):
                    glob_ok = True
                    break
            if not glob_ok or fora_do_escopo_no_quadro([(rot, sec)]):
                continue
            for bloco in qr.extrair_blocos_quadro(sec):
                if bloco.escala is None:
                    continue
                esc = float(bloco.escala)
                if "propost" not in _sem_acento(bloco.texto).lower():
                    continue
                for ln in bloco.texto.splitlines():
                    if not re_total.search(ln):
                        continue
                    vals = _celulas_da_linha(ln)
                    if any(ok(v * esc, valor) for v in vals):
                        return re.sub(r"\s+", " ", ln).strip()[:180]
    return None

def total_geral_no_escopo(fontes, valor, tol_abs=1000.0, tol_rel=0.005) -> Optional[str]:
    """R37 (auditoria da R35: linhas verdes com 'abrangencia nao demonstrada'):
    PROVA de abrangencia de um limite global sem abertura por produto - um
    quadro do documento-fonte cujo TOTAL GERAL traz `valor` e que nao tem
    nenhum produto fora do escopo do sistema. Devolve a linha TOTAL ou None."""
    if valor is None:
        return None
    valor = float(valor)
    ok = lambda a, b: abs(a - b) <= max(tol_abs, tol_rel * abs(b))
    for rot, tx in fontes or []:
        for cel, _res, ln in celulas_total_geral(tx):
            if any(ok(v, valor) for v in cel) and not fora_do_escopo_no_quadro([(rot, tx)]):
                return ln
    return None


def familias_no_quadro(fontes) -> Set[str]:
    """Familias (vocabulario do sistema) das linhas COM VALOR do quadro do
    limite (R36: deliberacao sem abertura por produto na extracao). Usa o
    mesmo classificador de familia do motor, linha a linha; linha que cita
    duas familias nao conta."""
    import produto as _p
    out: Set[str] = set()
    for _rot, tx in fontes or []:
        for bl in blocos_de_quadro(tx):
            for ln in bl.split("\n")[1:]:
                if not re.search(r"\d", ln) or re.search(r"total|jotecoga|geral", ln, re.IGNORECASE):
                    continue
                r = _p.classificar_familia(ln)
                if len(r.familias_candidatas) == 1:
                    out.add(r.familias_candidatas[0])
    return out
