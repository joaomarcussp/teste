import sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path[:0]=[str(ROOT),str(ROOT/'scripts')]
import aprovacao_origem as ao

class R48AprovacaoPorOrigem(unittest.TestCase):
    def test_pasta_comum_aprova_por_origem(self):
        p=r"\\srv\Atas Comite\2026\07\Cliente\_Fast-Track.msg"
        r=ao.avaliar_origem(p)
        self.assertTrue(r['aprovado_por_origem'])
        self.assertFalse(r['negado_por_origem'])
        st,sev,mot,_=ao.guardar_confirmacao('Divergência confirmada','Material','diferença real',p)
        self.assertEqual(st,'Divergência confirmada')
        self.assertEqual(mot,'diferença real')

    def test_negados_nao_sustenta_confirmacao(self):
        p=r"\\srv\Atas Comite\2026\07\negados\Cliente\pedido.msg"
        r=ao.avaliar_origem(p)
        self.assertTrue(r['negado_por_origem'])
        st,sev,mot,_=ao.guardar_confirmacao('Divergência confirmada','Material','diferença real',p)
        self.assertEqual(st,'Requer verificação manual')
        self.assertIn('negados',mot)

    def test_negados_variantes_caixa_genero(self):
        for nome in ('NEGADOS','Negado','negada','negadas'):
            self.assertEqual(ao.classificar_origem(fr"C:\Atas\{nome}\x.msg"),ao.NEGADO_POR_ORIGEM)

    def test_origem_indeterminada_nao_inventa_aprovacao(self):
        r=ao.avaliar_origem('[Fast-Track | Nível 1] Cliente | Renovação')
        self.assertFalse(r['aplicavel'])
        st,sev,mot,_=ao.guardar_confirmacao('Divergência confirmada','Material','diferença real','assunto solto.msg')
        self.assertEqual(st,'Divergência confirmada')
        self.assertEqual(mot,'diferença real')

    def test_regra_nao_promove_status_manual(self):
        p=r"\\srv\Atas Comite\2026\07\Cliente\pedido.msg"
        st,sev,mot,_=ao.guardar_confirmacao('Requer verificação manual','Informativo','escopo incerto',p)
        self.assertEqual(st,'Requer verificação manual')
        self.assertEqual(mot,'escopo incerto')

    def test_data_nao_e_reconstruida_por_voto(self):
        r=ao.avaliar_origem(r"\\srv\Atas Comite\2026\09\11.09.2026_Cliente\pedido.msg")
        self.assertNotIn('data_aprovacao',r)
        self.assertNotIn('quorum',str(r).lower())

class R48Rastreabilidade(unittest.TestCase):
    def test_causa_quorum_retirado(self):
        sys.path.insert(0,str(ROOT/'revisao_ultimate'))
        import causas_r48 as c
        a={'Status':'Requer verificação manual','Pendencia_A_Verificar':'quórum do Fast-Track não demonstrado'}
        b={'Status':'Divergência confirmada'}
        self.assertIn('R48 aprovação por origem',c.causa('T01',a,b))

    def test_causa_nao_promove_outra_pendencia(self):
        sys.path.insert(0,str(ROOT/'revisao_ultimate'))
        import causas_r48 as c
        a={'Status':'Requer verificação manual','Pendencia_A_Verificar':'escopo não demonstrado'}
        b={'Status':'Divergência confirmada'}
        self.assertIsNone(c.causa('T02',a,b))

    def test_limites_execucao_declaram_r48_sem_quorum_governante(self):
        import json
        itens=json.loads((ROOT/'revisao_ultimate/limites_execucao.json').read_text(encoding='utf-8'))
        txt=json.dumps(itens,ensure_ascii=False).lower()
        self.assertIn('natureza desta execução (r50)',txt)
        self.assertIn('aprovação por origem documental',txt)
        self.assertIn('parser de votos/quórum permanece apenas como diagnóstico histórico',txt)
        self.assertIn('rodada r50',txt)

if __name__=='__main__': unittest.main()
