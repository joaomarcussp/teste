import sys, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
import fonte_documental as fd

class TestR50BQuadroConsolidado(unittest.TestCase):
    def test_cp_r50_01_quadro_cruzado_entre_grupos(self):
        tx='''
Grupo Econômico: GRUPO ALFA
Resumo sem quadro consolidado aplicável.

Grupo Econômico: GRUPO BETA
Limite Global: R$ 310 MM
##BLOCO 1|TABELA|4col
GRUPO BETA | BRL MM    Aprovação ATUAL    Proposta
EMPRESA B    Garantia Firme    200    100
Jotecoga Banco XP              471    310
'''
        self.assertIsNone(fd.quadro_consolidado_grupo([('doc', tx)], 'GRUPO ALFA', 310_000_000))

    def test_mesma_secao_valida(self):
        tx='''
Grupo Econômico: GRUPO ALFA
Limite Global: R$ 310 MM
##BLOCO 1|TABELA|4col
GRUPO ALFA | BRL MM    Aprovação ATUAL    Proposta
EMPRESA A    Garantia Firme    200    100
Jotecoga Banco XP              471    310
'''
        self.assertIsNotNone(fd.quadro_consolidado_grupo([('doc', tx)], 'GRUPO ALFA', 310_000_000))

    def test_mesma_secao_sem_limite_global_rejeita(self):
        tx='''
Grupo Econômico: GRUPO ALFA
##BLOCO 1|TABELA|4col
GRUPO ALFA | BRL MM    Aprovação ATUAL    Proposta
Jotecoga Banco XP              471    310
'''
        self.assertIsNone(fd.quadro_consolidado_grupo([('doc', tx)], 'GRUPO ALFA', 310_000_000))

    def test_entidades_diferentes_validas_se_secao_declara_consolidacao(self):
        tx='''
Grupo Econômico: GRUPO ALFA
Limite Global: R$ 310 MM
##BLOCO 1|TABELA|4col
GRUPO ALFA | BRL MM    Aprovação ATUAL    Proposta
EMPRESA X    Garantia Firme    200    100
EMPRESA Y    Derivativos       50     50
Jotecoga Banco XP              471    310
'''
        self.assertIsNotNone(fd.quadro_consolidado_grupo([('doc', tx)], 'GRUPO ALFA', 310_000_000))

class TestR50CErrata(unittest.TestCase):
    def test_cp_r50_02_errata_de_outra_operacao(self):
        fontes=[
            ('pedido', 'Operação ALFA: limite R$ 75 MM. Grupo Econômico: GRUPO X.'),
            ('errata', '[ERRATA]\nOperação BETA\nOnde se lê R$ 75 MM, leia-se R$ 87,5 MM.\nGrupo Econômico: GRUPO X.'),
        ]
        self.assertIsNone(fd.retificacao_vinculada(fontes))

    def test_errata_mesma_operacao_explicita(self):
        fontes=[
            ('pedido', 'Operação ALFA: limite R$ 75 MM. Grupo Econômico: GRUPO X.'),
            ('errata', '[ERRATA]\nOperação ALFA\nOnde se lê R$ 75 MM, leia-se R$ 87,5 MM.\nConforme e-mail anterior.'),
        ]
        self.assertIsNotNone(fd.retificacao_vinculada(fontes))

    def test_errata_mesmo_grupo_sem_operacao_demonstrada(self):
        fontes=[
            ('pedido A', 'Operação ALFA: limite R$ 75 MM. Grupo Econômico: GRUPO X.'),
            ('pedido B', 'Operação BETA: limite R$ 75 MM. Grupo Econômico: GRUPO X.'),
            ('errata', '[ERRATA]\nGrupo Econômico: GRUPO X. Onde se lê R$ 75 MM, leia-se R$ 87,5 MM.'),
        ]
        self.assertIsNone(fd.retificacao_vinculada(fontes))

    def test_retificacao_ambigua_rejeita(self):
        fontes=[('errata','ERRATA Operação ALFA: corrigindo informações, R$ 75 MM e R$ 87,5 MM aparecem no anexo.')]
        self.assertIsNone(fd.retificacao_vinculada(fontes))

    def test_posterior_sem_linguagem_correcao_rejeita(self):
        fontes=[('posterior','Operação ALFA. Novo limite R$ 87,5 MM.')]
        self.assertIsNone(fd.retificacao_vinculada(fontes))

class TestR50DTranches(unittest.TestCase):
    def test_cp_r50_03_tranches_operacoes_diferentes(self):
        tx='''Operação ALFA: primeira tranche de R$ 8 MM, ainda vigente.
Operação BETA: segunda tranche adicional de R$ 12 MM.'''
        self.assertIsNone(fd.tranches_cumulativas([('doc', tx)]))

    def test_mesma_operacao_cumulativa_soma(self):
        tx='''Operação ALFA: primeira tranche de R$ 8 MM, ainda vigente.
Operação ALFA: segunda tranche adicional de R$ 12 MM, complementa a primeira.'''
        ev=fd.tranches_cumulativas([('doc',tx)])
        self.assertIsNotNone(ev)
        self.assertAlmostEqual(ev[2],20_000_000)

    def test_substitutiva_nao_soma(self):
        tx='''Operação ALFA: primeira tranche de R$ 8 MM.
Operação ALFA: segunda tranche de R$ 12 MM substitui integralmente a primeira.'''
        self.assertIsNone(fd.tranches_cumulativas([('doc',tx)]))

    def test_primeira_cancelada_nao_soma(self):
        tx='''Operação ALFA: primeira tranche de R$ 8 MM foi cancelada.
Operação ALFA: segunda tranche adicional de R$ 12 MM.'''
        self.assertIsNone(fd.tranches_cumulativas([('doc',tx)]))

    def test_ambigua_nao_soma(self):
        tx='''Primeira tranche R$ 8 MM. Segunda tranche R$ 12 MM.'''
        self.assertIsNone(fd.tranches_cumulativas([('doc',tx)]))

if __name__=='__main__': unittest.main()
